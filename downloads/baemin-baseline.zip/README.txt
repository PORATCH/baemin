Baemin Baseline prototype

Use a browser or a static HTTP server to open index.html.
The prototype was validated over HTTP in Chromium.
Local file access depends on browser policy.
All data and order/support interactions are mock.
Original screenshots were not supplied; visual fidelity is an approximation.
