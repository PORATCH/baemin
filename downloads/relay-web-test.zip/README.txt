Relay browser prototype

Open index.html in Chrome or Edge.
All agents, chat responses and terminal output are simulated.
No API keys or development server are required.
